<%*
  let title = tp.file.title
  if (title.startsWith("未命名")) {
    title = await tp.system.prompt("請輸入書名");
    await tp.file.rename(`${title}`);
  } 
  tR += ""
%>
書名：<%* tR += `${title}` %> 
作者：
譯者：
出版者：
出版日期：
語言：
章節：
建立日期： <% tp.date.now("YYYY-MM-DD") %>


## 節錄評論

- [ ] *預定完成日期 *(@<% tp.date.now("YYYY-MM-DD", 7) %>)

[製作示範](https://youtu.be/C0KCnQ3F3QA?t=164)

- 金句
> (將要記下的金句複製至此)

- 想法
(對金句的個人想法)


## 一問一答
- [ ] *預定完成日期* (@<% tp.date.now("YYYY-MM-DD", 10) %>)

[製作示範](https://youtu.be/C0KCnQ3F3QA?t=370)

- 這本書/這些章節在說什麼？
（用一句話、不分段落說明）

- 這本書/這些章節最吸引我的是什麼？
(以舉例或解釋作者動機說明)

- 我會向誰推薦這本書/這些章節？
(可以是具體的對象；可以是具備某些條件的人)

## HQ&A
- [ ] *預定完成日期* (@<% tp.date.now("YYYY-MM-DD", 14) %>)

- 這本書/這個章節的重點
  > (從這本書/這個章節的原文，摘錄我認為是重點的段落或句子)

- 問答清單

|問題|答案|
|:---|:---:|
|(提出能讓我回憶重點的問題)|(提出我對這個問題的回答)|
|(使用5W1H設計問題: What, Why, When, Where, Who, How)|(如果把問題丟給任何一種生成式AI產生回答，例如ChatGPT，要附上原始回答來源及內容，以及與AI的對話歷程)|

`請自行延伸清單內容`


## 心得輸出
- [ ] *預定完成日期* (@<% tp.date.now("YYYY-MM-DD", 21) %>)

(運用[瓦基](https://readingoutpost.com/about/)建議的[**萬能框架**](https://youtu.be/C0KCnQ3F3QA?t=1055)建立大綱，再寫成短篇心得)

- 觀點
  (這本書/這個章節在說什麼？)
  (我有什麼收穫？)
  
- 案例
  (分享令我印象深刻的問題、案例或故事)
  
- 總結
  (對一段金句發表想法)
  (我要推薦這本書/這個章節給誰)

> 模板改編來源：閱讀前哨站[化輸入為輸出｜挑戰活動－「小步慢跑挑戰」](https://waki.notion.site/waki/2d87ff977c884e63ba23afe64decd813)