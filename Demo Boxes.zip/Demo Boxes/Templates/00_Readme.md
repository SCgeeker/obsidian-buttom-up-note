**設定閱讀電子書與紙本書的筆記模板；快速鍵使用說明**

### 需要安裝的plugin
- [Templater](https://github.com/SilentVoid13/Templater)  指定模板存放位置
- [QuickAdd](https://github.com/chhoumann/quickadd) 設定筆記模板指令
	- 可由左側邊欄`開啟命令面板`，輸入QuickAdd: Fleet ，在指定資料夾`Fleet(靈感)`建立空白閱讀筆記
	- 結合快捷鍵，按快捷鍵在指定資料夾`Fleet(靈感)`建立可自行輸入書名的閱讀筆記
	- 本儲存庫已設快速鍵：`Alt + Shift + Z` 在指定資料夾`Fleet(靈感)`開啟新文件檔並輸入書名
- [Note Refactor](https://github.com/lynchjames/note-refactor-obsidian)分解閱讀筆記到再複習資料夾
	- 將已建立的閱讀筆記依閱讀階段，分解為三種**永久筆記**：`輸入筆記`、`再複習筆記`、`輸出筆記`
	- 本儲存庫已設永久筆記模板，有三種標籤：`#輸入筆記`、`#再複習筆記`、`#輸出筆記`
	- 選擇要分解的筆記內容，可由左側邊欄`開啟命令面板`，輸入`Note Refactor: Exact selection to newnote -firtline as file name`，在指定資料夾`Zettels/Reforcing`建立永久筆記
	- 可設定快捷鍵，按快捷鍵在指定資料夾`Zettels/Reforcing`建立永久筆記
	- 本儲存庫已設快速鍵：`Cltr + Alt + N` 選好要分解的內容，在指定資料夾`Zettels/Reforcing`建立永久筆記

### 非需要安裝的plugin
- [Calendar](https://github.com/liamcain/obsidian-calendar-plugin) 在右側邊欄展示月曆及提醒日期
- [Reminder](https://github.com/uphy/obsidian-reminder) 設定提醒日期

### 模板列表
	  [[Bottom-up note]]


### plugin設定截圖

- Templater設定
![[Pasted image 20230613170322.png]]
![[Pasted image 20230613170221.png]]

- QuickAdd設定
  ![[Pasted image 20230613171301.png]]
  ![[Pasted image 20230613171340.png]]![[Pasted image 20230613171421.png]]

- Note Refactor
  ![[Pasted image 20230709114634.png]]
![[Pasted image 20230709114702.png]]